package main

import (
	"lessons/lesson5/aliases"
	"lessons/lesson5/maps"
	"lessons/lesson5/methods"
	"lessons/lesson5/slices"
	"lessons/topics/interfaces"
	"lessons/topics/parallel"
	"lessons/topics/structs"
)

func main() {
	aliases.Test()
	structs.Test()
	methods.Test()
	slices.Test()
	maps.Test()
	interfaces.Test()
	parallel.Test()
}
