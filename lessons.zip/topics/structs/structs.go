package structs

import (
	"fmt"
	"lessons/topics/aliases"
	"time"
)

type msg struct {
	isError   bool
	isSuccess bool
	code      int
	message   aliases.Message
}
type msgPool []msg

var messages msgPool = msgPool{
	{isError: false, isSuccess: true, code: 101, message: "Completed"},
	{isError: true, isSuccess: false, code: 201, message: "Method not allowed"},
	{isError: false, isSuccess: false, code: 301, message: "Debug info"},
}

var MsgSlice []string = []string{
	"Message #1",
	"Message #2",
	"Message #3",
	"Message #4",
	"Message #5",
	"Message #6",
	"Message #7",
	"Message #8",
}

func Test() {
	var logger aliases.LogWithCode = aliases.Logger()

	fmt.Println("-== Structs ==-")
	for _, m := range messages {
		var mtype aliases.MessageType
		switch m.isSuccess {
		case m.isError:
			mtype = "error"
		case !m.isError:
			mtype = "success"
		default:
			mtype = "debug"
		}
		logger(m.message, mtype, m.code)
	}
	time.Sleep(2 * time.Second)
}
